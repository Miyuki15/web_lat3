import React from "react";

function contact() {
  return (
    <div>
      <h2>Contact Us</h2>
      <p>Feel free to contact us for any inquiries.</p>
    </div>
  );
}

export default Contact;
