import React from "react";

function about() {
  return (
    <div>
      <h2>About Us</h2>
      <p>We are a company that does amazing things.</p>
    </div>
  );
}

export default AboutUs;
