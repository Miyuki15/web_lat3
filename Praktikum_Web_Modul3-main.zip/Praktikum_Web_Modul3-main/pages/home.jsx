import React from "react";

function home() {
  return (
    <div>
      <h2>INI HOME</h2>
      <ul>
        <li>Info 1</li>
        <li>Info 11</li>
        <li>Info 3</li>
      </ul>
    </div>
  );
}

export default Home;
