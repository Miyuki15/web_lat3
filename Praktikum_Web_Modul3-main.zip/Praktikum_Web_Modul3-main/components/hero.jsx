import React from "react";

function hero() {
  return (
    <div>
      <h1>Welcome to Our Website</h1>
      <p>Discover amazing things on our website.</p>
    </div>
  );
}

export default Hero;
