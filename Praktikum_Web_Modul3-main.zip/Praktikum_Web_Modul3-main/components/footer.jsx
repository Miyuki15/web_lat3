import React from "react";

function footer() {
  return (
    <footer>
      <p>&copy; 2023 Your Company. All rights reserved.</p>
    </footer>
  );
}

export default Footer;
